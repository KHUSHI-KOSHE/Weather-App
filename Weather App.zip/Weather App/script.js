let lastCity = "";

/* ==== Weather Icon Function (ADDED) ===== */
function getWeatherIcon(condition) {
    condition = condition.toLowerCase();

    if (condition.includes("clear")) return "☀️";
    if (condition.includes("cloud")) return "☁️";
    if (condition.includes("rain")) return "🌧️";
    if (condition.includes("thunder")) return "⛈️";
    if (condition.includes("drizzle")) return "🌦️";
    if (condition.includes("snow")) return "❄️";
    if (condition.includes("mist") || condition.includes("fog") || condition.includes("haze"))
        return "🌫️";

    return "❓";
}

/* ==== Dark Mode ===== */
function toggleMode() {
    document.body.classList.toggle("dark");
}

const toggle = document.getElementById("darkSwitch");

toggle.addEventListener("change", () => {
    document.body.classList.toggle("dark");
});

/* ===== GET WEATHER ===== */
async function getWeather(cityName) {
    let city = cityName || document.getElementById("city").value;
    if (!city) return alert("Enter city!");

    lastCity = city;

    const loading = document.getElementById("loading");
    const card = document.getElementById("weatherCard");

    loading.style.display = "block";
    card.style.display = "none";

    const apiKey = "859f810c9765a52945ba01bd27e4b13f";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try {
        const res = await fetch(url);
        const data = await res.json();

        loading.style.display = "none";

        if (data.cod == "404") {
            card.style.display = "block";
            card.innerHTML = "City not found!";
            return;
        }

        document.getElementById("wCity").textContent = data.name;
        document.getElementById("wTemp").textContent = `🌡 Temperature: ${data.main.temp}°C`;
        document.getElementById("wMain").textContent = `🌤 Weather: ${data.weather[0].main}`;
        document.getElementById("wHum").textContent = `💧 Humidity: ${data.main.humidity}%`;
        document.getElementById("wWind").textContent = `🌬 Wind: ${data.wind.speed} km/h`;

        /* ===== Emoji Weather Icon ===== */
        const condition = data.weather[0].main;
        document.getElementById("wEmoji").textContent = getWeatherIcon(condition);

        card.style.display = "block";

    } catch (err) {
        alert("Error fetching weather!");
        loading.style.display = "none";
    }
}


/* ===== Card Actions ===== */
function cardAction(type) {
    if (!lastCity) {
        alert("Please search a city first!");
        return;
    }

    if (type === 'today') {
        alert("Showing Today’s Weather…");
    }

    if (type === 'week') {
        alert("Weekly forecast feature coming soon!");
    }

    if (type === 'aqi') {
        alert("AQI feature coming soon!");
    }
}


/* ===== REFRESH ===== */
function refreshWeather() {
    if (!lastCity) return alert("Search a city first!");
    getWeather(lastCity);
}
